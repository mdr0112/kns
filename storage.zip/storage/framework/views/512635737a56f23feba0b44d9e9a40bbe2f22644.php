

<?php $__env->startSection('judul', 'List Orderan'); ?>

<?php $__env->startSection('konten'); ?>
<div class="row">
    <div class="col-md-12">
        
        <div class="card">
            <div class="card-header">
              <h3 class="card-title">LIST DAFTAR ORDERAN</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="mytable" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th>NO</th>
                  <th>NO.PO</th>
                  <th>Vendor</th>
                  <th>No.HP</th>
                  <th>Deadline</th>
                  <th>Status</th>
                  <th>Detail</th>
                </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                      
                <tr>
                  <td><?php echo e($loop->iteration); ?></td>
                  <td><?php echo e($order->no_po); ?></td>
                  <td><?php echo e($order->nama_vendor); ?>

                  </td>
                  <td><?php echo e($order->no_hp); ?></td>
                  <td><?php echo e(Carbon\Carbon::parse($order->deadline)->format('d-M-Y')); ?></td>
                  <td>
                    <?php if($order->status == 0): ?>
                    <span class="badge badge-danger">Belum Di Produksi</span>
                    <?php elseif($order->status == 1): ?>
                    <span class="badge badge-warning">Proses Produksi</span>
                    <?php elseif($order->status == 2): ?>
                    <span class="badge badge-info">Siap Diantar</span>
                    <?php else: ?>
                    <span class="badge badge-success">Selesai Diantar</span>
                    <?php endif; ?>
                  </td>
                  <td>
                      <a href="/lihat_orderan/detail/<?php echo e($order->id); ?>" class="btn btn-outline-info btn-sm"><i class="fas fa-eye"> Detail</i></a>
                      <?php if($order->status == 0): ?>
                      <a href="/orderan/mulai_produksi/<?php echo e($order->id); ?>" class="btn btn-outline-warning btn-sm "><i class="fas fa-dolly"> Mulai Produksi</i></a>
                      <?php elseif($order->status == 1): ?>
                      <a href="/orderan/selesai_produksi/<?php echo e($order->id); ?>" class="btn btn-warning btn-sm"><i class="fas fa-check"> Selesai Produksi</i></a>
                      <?php elseif($order->status == 2): ?>
                      <a href="/orderan/cetak_invoice/<?php echo e($order->id); ?>" class="btn btn-outline-success btn-sm "><i class="fas fa-truck"> Antar & Print Invocie</i></a>
                      <?php endif; ?>
                  </td>
                </tr>             
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
    </div>
</div>



    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Konveksi_new_speed\resources\views/admin/orderan/crud/list.blade.php ENDPATH**/ ?>