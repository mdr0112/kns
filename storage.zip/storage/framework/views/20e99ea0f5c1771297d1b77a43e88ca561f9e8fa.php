
<?php $__env->startSection('judul', 'History Pembayaran'); ?>
<?php $__env->startSection('konten'); ?>
    
<div class="card">
      <div class="card-header">
        <h3 class="card-title">HISTROY PEMBAYARAN </h3>
        <div class="card-tools">
          <a href="javascript:window.history.go(-1);" class="btn btn-outline-dark btn-sm" style="border-radius: 15px"><i class="fa fa-arrow-left"> Kembali</i></a>
          <button type="button" class="btn btn-tool" data-card-widget="collapse">
            <i class="fas fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="mytable" class="table table-bordered table-striped">
          <thead>
          <tr>
            <th class="text-center">No.</th>
            <th class="text-center">Nama Klien</th>
            <th class="text-center">Jenis Pekerjaan</th>
            <th class="text-center">Nama Vendor</th>
            <th class="text-center">Target</th>
            <th class="text-center">Penyelesaian</th>
            <th class="text-center">Harga Jasa</th>
            <th class="text-center" style="width: 15%">Total</th>
            <th class="text-center">Status</th>
          </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
          <tr>
            <td class="text-center"><?php echo e($loop->iteration); ?></td>
            <td class="text-center"><?php echo e($item->vendor); ?></td>
            <td class="text-center">
              <?php if($item->jenis_pekerjaan == 'Jahit'): ?>
              <span class="badge badge-primary">Jahit</span>
              <?php else: ?>
              <span class="badge badge-dark">Potong</span>
              <?php endif; ?>
            </td>
            <td class="text-center"><?php echo e($item->nama_pekerja); ?></td>
            <td class="text-center"><?php echo $item->qty_barang." "."Pcs"?></td>
            <td class="text-center"><?php echo $item->qty_pekerjaan." "."Pcs"?></td>
            <td class="text-center"><?php echo "Rp.".' '.number_format($item->harga_jasa)?></td>
            <td class="text-center"><?php echo "Rp.".' '.number_format($item->total)?></td>
            <td class="text-center">
              <?php if($item->keterangan == 'sudah_di_bayar'): ?>
              <span class="badge badge-pill badge-success">Sudah Dibayar</span>
              <?php else: ?>
              <span class="badge badge-pill badge-danger">Belum Dibayar</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tfoot>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
  <!-- /.col -->
</div>
<!-- /.row -->
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KNS\resources\views/admin/penggajian/all_list.blade.php ENDPATH**/ ?>