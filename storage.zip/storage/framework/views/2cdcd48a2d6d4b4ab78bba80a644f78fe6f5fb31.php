
<?php $__env->startSection('judul', 'Halaman Stok Barang'); ?>

<?php $__env->startSection('konten'); ?>

<div class="card">
      <div class="card-header bg-dark">
            <center><h3 class="card-title">LIST LOKER STOK BARANG </h3></center>
      </div>
<div class="row ml-2 mt-4 mr-2">
      <?php $__currentLoopData = $join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>          
      <div class="col-sm-3 col-sm-2">
            <?php if($item->id_loker == 'L1'): ?>
            <div class="small-box bg-warning">
              <?php endif; ?>
            <?php if($item->id_loker == 'L2'): ?>
            <div class="small-box bg-info">
              <?php endif; ?>
            <?php if($item->id_loker == 'L3'): ?>
            <div class="small-box bg-dark">
              <?php endif; ?>
            <?php if($item->id_loker == 'L4'): ?>
            <div class="small-box bg-danger">
              <?php endif; ?>
            <?php if($item->id_loker == 'L5'): ?>
            <div class="small-box bg-primary">
              <?php endif; ?>
            <div class="inner">
                  <h3><?php echo e($item->nama_loker); ?></h3>
                  <p><?php echo e($item->nama_vendor); ?></p>
              <p><?php echo e($item->nama_barang); ?>, <?php echo e($item->size); ?>, <?php echo e($item->warna); ?>, <?php echo e($item->qty); ?> Pcs</p>
           </div>
            <div class="icon">
              <i class="fas fas fa-boxes"></i>
          </div>
           <a href="/show_stok/<?php echo e($item->id); ?>" class="small-box-footer"> Lihat <i class="fas fa-arrow-circle-right"></i></a>
          </div>
       </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Konveksi_new_speed\resources\views/admin/stok/crud/index.blade.php ENDPATH**/ ?>