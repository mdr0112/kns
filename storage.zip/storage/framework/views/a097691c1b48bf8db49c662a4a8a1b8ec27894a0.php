
<?php $__env->startSection('judul', 'Detail Stok Barang'); ?>
<?php $__env->startSection('konten'); ?>
    
<div class="card">
      <div class="card-header">
        <h3 class="card-title">LIST DAFTAR STOK BARANG <span class="badge badge-warning"><b><?php echo e($join[0]->nama_loker); ?></span></b></h3>
        <div class="card-tools">
          <a href="javascript:window.history.go(-1);" class="btn btn-outline-dark btn-sm" style="border-radius: 15px"><i class="fa fa-arrow-left"> Kembali</i></a>  
          <a href="/print_stok/<?php echo e($join[0]->nama_loker); ?>" class="btn btn-info btn-sm" style="border-radius: 15px"><i class="fas fa-print"></i> Print</a>
          <button type="button" class="btn btn-tool" data-card-widget="collapse">
            <i class="fas fa-minus"></i>
          </button>
        </div>
      </div>
      <!-- /.card-header -->
      <div class="card-body">
        <table id="mytable" class="table table-bordered table-striped">
          <thead>
          <tr>
            <th class="text-center">No.</th>
            <th class="text-center">Nama Vendor</th>
            <th class="text-center">Nama Barang</th>
            <th class="text-center">Warna</th>
            <th class="text-center">Bahan</th>
            <th class="text-center">Size</th>
            <th class="text-center">QTY</th>
            <th class="text-center">Update Terakhir</th>
            <th class="text-center">Pemeriksa</th>
          </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                
          <tr>
            <td class="text-center"><?php echo e($loop->iteration); ?></td>
            <td class="text-center"><?php echo e($item->nama_vendor); ?></td>
            <td class="text-center"><?php echo e($item->nama_barang); ?></td>
            <td class="text-center"><?php echo e($item->warna); ?></td>
            <td class="text-center"><?php echo e($item->bahan); ?></td>
            <td class="text-center"><?php echo e($item->size); ?></td>
            <td class="text-center"><?php echo $item->qty." "."Pcs"?></td>
            <td class="text-center"><?php echo e(Carbon\Carbon::parse($item->tgl_pemeriksaan)->format('d-M-Y')); ?></td>
            <td class="text-center"><?php echo e($item->pemeriksa); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tfoot>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
  <!-- /.col -->
</div>
<!-- /.row -->
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Konveksi_new_speed\resources\views/admin/stok/crud/show_stok.blade.php ENDPATH**/ ?>