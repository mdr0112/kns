

<?php $__env->startSection('judul', 'Orderan On Proses'); ?>

<?php $__env->startSection('konten'); ?>
<div class="row">
  <div class="col-12">
    <div class="card">
      <div class="card-header">
        <h3 class="card-title"><i class="far fa-clipboard"> DAFTAR ORDERAN SELESAI</i></h3>
      </div>
      <!-- ./card-header -->
      <div class="card-body">
        <table class="table table-bordered table-hover">
          <thead>
            <tr>
              <th class="text-center">NO.</th>
              <th class="text-center">No. PO</th>
              <th class="text-center">Vendor</th>
              <th class="text-center">Tanggal Pemesanan</th>
              <th class="text-center">Status</th>
              <th class="text-center">Opsi</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                  
            <tr data-widget="expandable-table" aria-expanded="false">
              <td class="text-center"><?php echo e($loop->iteration); ?></td>
              <td class="text-center"><?php echo e($item->no_po); ?></td>
              <td class="text-center"><?php echo e($item->nama_vendor); ?></td>
              <td class="text-center"><?php echo e(Carbon\Carbon::parse($item->tgl_order)->format('d-M-Y')); ?></td>
            
              <td class="text-center"><span class="badge badge-success">Orderan Selesai</td>
          <td class="text-center">
            <a href="/lihat_orderan/detail/<?php echo e($item->id); ?>" class="btn btn-success btn-sm"><i class="fas fa-eye"> Detail</i></a>
            <a href="/orderan/cetak_invoice/<?php echo e($item->id); ?>" class="btn btn-outline-info btn-sm "><i class="fa fa-receipt"> Lihat Invoice</i></a>
          </td>
            </tr>
            <tr class="expandable-body">
              <td colspan="5">
                <p>
                  <ul>
                    <?php if($item->sistem_dp == 'YA'): ?>                        
                      <li>
                          <h4>Total DP, Rp. <?php echo e(number_format($item->dp),2, ',', '.'); ?></h4> 
                        </li>
                        <?php else: ?>
                        <h4>Tidak Ada DP</h4>   
                    <?php endif; ?>
                  </ul>
                </p>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 
          </tbody>
        </table>
      </div>
      <!-- /.card-body -->
    </div>
    <!-- /.card -->
  </div>
</div>



    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Konveksi_new_speed\resources\views/admin/orderan/status/orderan_selesai.blade.php ENDPATH**/ ?>