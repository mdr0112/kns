
<?php $__env->startSection('judul', 'Print Stok Barang'); ?>
<?php $__env->startSection('konten'); ?>

<div class="row">
      <div class="col-md-12">
          <div class="invoice p-3 mb-3">
              <!-- title row -->
              <div class="row">
                <div class="col-12">
                      
              <!-- this row will not appear when printing -->
              <div class="row no-print">
                  <div class="col-6">
                  </div>
                  <div class="col-4">
                  </div>
                  <div class="col-2">
                    <button onclick="window.print()"rel="noopener" target="_blank" class="btn btn-info btn-block btn-sm"><i class="fas fa-print"></i> Print</button>
                  </div>
                </div>
                <br>
                  <h4>
                    <img src="/assets/dist/img/AdminLTELogo.png" style="width: 190px; border-radius: 8px">
                    <center> <b> STOK BARANG <?php echo e($join[0]->nama_loker); ?> </b> </center>
                    <small class="float-right">Tanggal Update: <b><?php echo e($join[0]->tgl_pemeriksaan); ?></b></small><br>
                    <small class="float-right">Pemeriksa: <b><?php echo e($join[0]->pemeriksa); ?></b></small>
                  </h4>
                </div>
                <!-- /.col -->
              </div>
              <!-- info row -->
           
              <!-- Table row -->
              <div class="row">
                <div class="col-12 table-responsive">
                  <table class="table table-striped">
  
                    <table class="table table-bordered">                                    
                      <thead>
                        <tr>
                          <th class="text-center">No.</th>
                          <th class="text-center">Nama Vendor</th>
                          <th class="text-center">Nama Barang</th>
                          <th class="text-center">Bahan</th>
                          <th class="text-center">Warna</th>
                          <th class="text-center">Size</th>
                          <th class="text-center">Qty</th>
                        </tr>
                      </thead>
                      <tbody>
                        <?php $__currentLoopData = $join; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <td class="text-center"><?php echo e($loop->iteration); ?></td>
                              <td class="text-center"><?php echo e($item->nama_vendor); ?></td>
                              <td class="text-center"><?php echo e($item->nama_barang); ?></td>
                              <td class="text-center"><?php echo e($item->bahan); ?></td>
                              <td class="text-center"><?php echo e($item->warna); ?></td>
                              <td class="text-center"><?php echo e($item->size); ?></td>
                              <td class="text-center"><?php echo $item->qty." "."Pcs" ?></td>
                            </tr>                  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                </div>
              </div>
            </div>
            <!-- /.invoice -->
      </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Konveksi_new_speed\resources\views/admin/stok/crud/print_stok.blade.php ENDPATH**/ ?>