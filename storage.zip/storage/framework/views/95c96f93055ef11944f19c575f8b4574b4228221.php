
<?php $__env->startSection('judul', 'Omset Bulanan'); ?>

<?php $__env->startSection('konten'); ?>

<div class="container">
      <div class="row">
            <div class="col-md-12">
                  <div class="card mt-2">
                    <form action="/omset_bulanan" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="card-header">
                              <h3 class="card-title"><i class="fas fa-chart-line"> OMSET BULANAN </i></h3>
                        </div>
                        <div class="col-md-6 mt-2">
                              <div class="form-group row">
                                    <div class="col-sm-6">
                                        <select class="form-control" name="tahun">
                                            <option selected="selected" disabled>Cari Berdasarkan Tahun</option>
                                            <option value="2024">2024</option>
                                            <option value="2025">2025</option>
                                          </select>                        
                                        </div>
                                        <button type="submit" class="btn btn-sm btn-secondary"><i class="fas fa-search"> Cari</i></button>
                                     </div>
                                    </form>
                                  </div>
                            <div class="card-body">
                                  <div id="grafik"></div>
                      </div>                    
                  </div>
            </div>
      </div>
</div>

<script>
       // Create the chart
       Highcharts.chart('grafik', {
    chart: {
        type: 'line'
    },
    title: {
        text: 'SILAKAN PILIH TAHUN REKAP'
    },
    subtitle: {
        text: 'BiruSaga Cakrawala'
    },
    xAxis: {
        categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
    },
    yAxis: {
        title: {
            text: 'Omseta'
        }
    },
    plotOptions: {
        line: {
            dataLabels: {
                enabled: true
            },
            enableMouseTracking: false
        }
    },
    series: [{
        name: 'Omset Per-bulan',
        data: [
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
           0,
        ]
    }]
});
</script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\KNS\resources\views/admin/omset/bulanan/index.blade.php ENDPATH**/ ?>