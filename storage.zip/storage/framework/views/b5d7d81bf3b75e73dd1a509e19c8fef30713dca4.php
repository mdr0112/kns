
<!DOCTYPE html>
<html lang="en">
  <head>
    <title>BIRUsaga.com</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Work+Sans:100,200,300,400,700,800" rel="stylesheet">
    <link rel="stylesheet" href="/assets/plugins/fontawesome-free/css/all.min.css">


    <link rel="stylesheet" href="/asset_login/css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="/asset_login/css/animate.css">
    
    <link rel="stylesheet" href="/asset_login/css/owl.carousel.min.css">
    <link rel="stylesheet" href="/asset_login/css/owl.theme.default.min.css">
    <link rel="stylesheet" href="/asset_login/css/magnific-popup.css">

    <link rel="stylesheet" href="/asset_login/css/aos.css">

    <link rel="stylesheet" href="/asset_login/css/ionicons.min.css">

    
    <link rel="stylesheet" href="/asset_login/css/flaticon.css">
    <link rel="stylesheet" href="/asset_login/css/icomoon.css">
    <link rel="stylesheet" href="/asset_login/css/style.css">
  </head>
  <body>
    
  <nav class="navbar navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
      <a class="navbar-brand" href="#">APLIKASI | BIRUsaga</a>
   
    </div>
  </nav>
    <!-- END nav -->
    
    <!-- <div class="js-fullheight"> -->
    <div class="hero-wrap js-fullheight" style="zoom: 85%">
      <div class="overlay"></div>
      <div id="particles-js"></div>
      <div class="container">
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('konten'); ?>
        <div class="row no-gutters slider-text align-items-center justify-content-center" data-scrollax-parent="true">
          <div class="col-md-6 ftco-animate text-center" data-scrollax=" properties: { translateY: '70%' }">
            <h1 class="mb-4" data-scrollax="properties: { translateY: '30%', opacity: 1.6 }">Aplikasi Monitoring <strong>BiruSAGA</strong></h1>
            <p data-scrollax="properties: { translateY: '30%', opacity: 1.6 }"><a href="#login" data-toggle="modal" class="btn btn-primary px-5 py-3"><i class="fas fa-sign-in-alt"> Klik untuk LOGIN</i></a></p>
          </div>
        </div>
      </div>
    </div>
    
 
    <div class="modal fade" id="login" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" style="zoom: 85%">
        <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
              <div class="modal-body">
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title"> Form Login </h5>
                    </div>
                        <div class="row justify-content-center">
                            <div class="col-md-12">
                                    <div class="card-body">
                                        <form method="POST" action="<?php echo e(route('login')); ?>">
                                            <?php echo csrf_field(); ?>
                    
                                            <div class="form-group row">
                                                <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('E-Mail')); ?></label>
                    
                                                <div class="col-md-8">
                                                    <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="Masukan Email..">
                    
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                    
                                            <div class="form-group row">
                                                <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Password')); ?></label>
                    
                                                <div class="col-md-8">
                                                    <input type="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required autocomplete="current-password" placeholder="Masukan Password" id="pass">
                    
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <span class="invalid-feedback" role="alert">
                                                            <strong><?php echo e($message); ?></strong>
                                                        </span>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                    
                                            <div class="form-group row mb-0">
                                                <div class="col-md-8 offset-md-2">
                                                    <button type="submit" class="btn btn-primary btn-block">
                                                        <?php echo e(__('Login')); ?>

                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
 
  

  <script src="/asset_login/js/jquery.min.js"></script>
  <script src="/asset_login/js/jquery-migrate-3.0.1.min.js"></script>
  <script src="/asset_login/js/popper.min.js"></script>
  <script src="/asset_login/js/bootstrap.min.js"></script>
  <script src="/asset_login/js/jquery.easing.1.3.js"></script>
  <script src="/asset_login/js/jquery.waypoints.min.js"></script>
  <script src="/asset_login/js/jquery.stellar.min.js"></script>
  <script src="/asset_login/js/owl.carousel.min.js"></script>
  <script src="/asset_login/js/jquery.magnific-popup.min.js"></script>
  <script src="/asset_login/js/aos.js"></script>
  <script src="/asset_login/js/jquery.animateNumber.min.js"></script>
  <script src="/asset_login/js/bootstrap-datepicker.js"></script>
  <script src="/asset_login/js/jquery.timepicker.min.js"></script>
  <script src="/asset_login/js/particles.min.js"></script>
  <script src="/asset_login/js/particle.js"></script>
  <script src="/asset_login/js/scrollax.min.js"></script>
 
  <script src="/asset_login/js/google-map.js"></script>
  <script src="/asset_login/js/main.js"></script>
    
  </body>
</html><?php /**PATH D:\KNS\resources\views/welcome.blade.php ENDPATH**/ ?>